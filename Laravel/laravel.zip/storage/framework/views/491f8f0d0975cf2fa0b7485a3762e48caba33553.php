<html>

<body>

    <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        Nombre:  <?php echo e($member['nombre_cat']); ?>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
<html>
<?php /**PATH /home/domingo/Escritorio/PI/pi_2daw2021/Laravel/resources/views/categoria.blade.php ENDPATH**/ ?>