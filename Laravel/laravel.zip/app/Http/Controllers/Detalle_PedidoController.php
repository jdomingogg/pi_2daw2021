<?php

namespace App\Http\Controllers;

use App\Models\Detalle_Pedido;
use Illuminate\Http\Request;

class Detalle_PedidoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $ar = Detalle_Pedido::all();
        $ar1 = $ar->toArray();
        return response()->json($ar);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Detalle_Pedido::create($request->all());
        return redirect()->away('https://www.google.com');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Detalle_Pedido  $detalle_Pedido
     * @return \Illuminate\Http\Response
     */
    public function show(Detalle_Pedido $detalle_Pedido)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Detalle_Pedido  $detalle_Pedido
     * @return \Illuminate\Http\Response
     */
    public function edit(Detalle_Pedido $detalle_Pedido)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Detalle_Pedido  $detalle_Pedido
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Detalle_Pedido $detalle_Pedido)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Detalle_Pedido  $detalle_Pedido
     * @return \Illuminate\Http\Response
     */
    public function destroy(Detalle_Pedido $detalle_Pedido)
    {
        //
    }
}
